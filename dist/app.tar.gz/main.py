import flet as ft
from flet import Container
from flet import Column, Row
from flet_core import UserControl
import time

# Styles
textfield_style = {
    "border_width": 1.5,
    "text_size": 12,
    "cursor_height": 16,
    "border_radius": 5,
    "height": 38,
    "focused_border_color": "#05B7FF",
    "cursor_color": "#05B7FF"
}

button_style = {
    "height": 38,
    "style": ft.ButtonStyle(shape={"": ft.RoundedRectangleBorder(radius=5)}),
    "disabled": False,
    "expand": True
}


# Styles


class NavButton(UserControl):
    def __init__(self, text, function=None):
        super().__init__()
        self.text = text
        self.function = function

    def hover_effect(self, e):
        if e.control.content.color == "#C4C4C4":
            e.control.content.color = "#5F7FFF"
            e.control.content.size = 18
            e.control.content.weight = ft.FontWeight.W_700
            self.update()
        else:
            e.control.content.color = "#C4C4C4"
            e.control.content.size = 16
            e.control.content.weight = ft.FontWeight.W_500
            self.update()

    def build(self):
        return Container(
            ft.Text(value=self.text, weight=ft.FontWeight.W_500, color="#C4C4C4", size=16, font_family="Arial"),
            padding=ft.padding.only(10, 15, 10, 10), on_hover=lambda e: self.hover_effect(e),
            on_click=self.function)


class TextField(ft.TextField):
    def __init__(self, placeholder, password: bool):
        super().__init__(**textfield_style, hint_text=placeholder, password=password)


class Button(ft.ElevatedButton):
    def __init__(self, text: str, icon=None):
        super().__init__(**button_style, text=text, icon=icon)


class HomePage(ft.Column):
    def __init__(self, Page):
        super().__init__()
        self.Page = Page

        main_tagline = Container(ft.Text(value="Easily Upload, Retrieve, and Share Files Anytime.", weight=ft.FontWeight.W_200, col={"md":3}), padding=ft.padding.only(left=10, right=10), expand=True, alignment=ft.alignment.center)

        self.upload_button = Button(text="Upload Now")
        self.browse_button = Button(text="Browse")

        call_to_action_buttons = Row(
            [Container(self.upload_button, padding=ft.padding.only(left=10, right=8), expand=True),
             Container(self.browse_button, padding=ft.padding.only(left=10, right=8), expand=True)],
            alignment=ft.MainAxisAlignment.SPACE_EVENLY)

        self.upload_feature = Container(
            self.feature(ft.icons.UPLOAD_FILE_ROUNDED, "Easy Uploads", "Upload Any File Format In Seconds."), padding=5)
        self.secure_feature = Container(
            self.feature(ft.icons.CLOUD_ROUNDED, "Secure Storage", "Your Files Are Safe And Accessible Anytime."),
            padding=5)
        self.download_feature = Container(self.feature(ft.icons.DOWNLOAD_ROUNDED, "Quick Downloads",
                                                       "Retrieve Your Files And Download Files From Others Instantly."),
                                          padding=5)
        self.features = Container(Row([self.upload_feature, self.secure_feature, self.download_feature],
                                        alignment=ft.MainAxisAlignment.SPACE_EVENLY))

        if Page.width > 468:
            self.upload_feature.content.controls[0].content.size = 120
            self.upload_feature.content.controls[1].alignment = ft.alignment.center_right
            self.upload_feature.content.controls[1].content.size = 17
            self.download_feature.content.controls[0].content.size = 120
            self.download_feature.content.controls[1].alignment = ft.alignment.center_right
            self.download_feature.content.controls[1].content.size = 17
            self.secure_feature.content.controls[0].content.size = 120
            self.secure_feature.content.controls[1].alignment = ft.alignment.center_right
            self.secure_feature.content.controls[1].content.size = 17
            Page.update()
        else:
            self.upload_feature.content.controls[0].content.size = 80
            self.upload_feature.content.controls[1].alignment = ft.alignment.center_right
            self.upload_feature.content.controls[1].content.size = 12
            self.download_feature.content.controls[0].content.size = 80
            self.download_feature.content.controls[1].alignment = ft.alignment.center_right
            self.download_feature.content.controls[1].content.size = 12
            self.secure_feature.content.controls[0].content.size = 80
            self.secure_feature.content.controls[1].alignment = ft.alignment.center_right
            self.secure_feature.content.controls[1].content.size = 12
            Page.update()

        recent_uploads_banner = ft.Text(value="Recent Uploads", size=18, weight=ft.FontWeight.W_700)
        recent_col = Column([
            Container(recent_uploads_banner, padding=10),
            Container(padding=10),
            Row([Container(Row(expand=True))], expand=True, scroll=ft.ScrollMode.AUTO)
        ])
        recent_frame = Container(recent_col, bgcolor=ft.colors.BLUE_300, border_radius=10, height=200, padding=10,
                                 gradient=ft.LinearGradient(
                                     colors=["blue100", "blue200", "blue300", "blue400", "blue500", "blue600",
                                             "blue700"], begin=ft.alignment.top_right, end=ft.alignment.bottom_left))

        popular_uploads_banner = ft.Text(value="Popular Uploads", size=18, weight=ft.FontWeight.W_700)
        popular_col = Column([
            Container(popular_uploads_banner, padding=10),
            Container(padding=10),
            Row([Container(Row(expand=True))], expand=True, scroll=ft.ScrollMode.AUTO)
        ])
        popular_frame = Container(popular_col, bgcolor=ft.colors.BLUE_300, border_radius=10, height=200, padding=10,
                                  gradient=ft.LinearGradient(
                                      colors=["blue200", "blue300", "blue400", "blue500", "blue600", "blue700"],
                                      begin=ft.alignment.top_left, end=ft.alignment.bottom_right))

        t_n_c_text = ft.Text(value="Terms and Conditions", color=ft.colors.BLUE_700, weight=ft.FontWeight.W_400,
                             size=13)
        privacy_policy_text = ft.Text(value="Privacy Policy", color=ft.colors.BLUE_700, size=13,
                                      weight=ft.FontWeight.W_400)
        sep = ft.Text(" | ")
        links_row = Row([t_n_c_text, sep, privacy_policy_text], alignment=ft.MainAxisAlignment.CENTER)

        self.controls = [Row([main_tagline], alignment=ft.MainAxisAlignment.CENTER), Container(padding=10),
                         self.features,
                         Container(padding=30), call_to_action_buttons, Container(padding=20), popular_frame,
                         Container(padding=20), recent_frame, Container(padding=20), links_row, Container(padding=10)]

    def feature(self, icon, text, tooltip):
        if self.Page.width > 468:
            feature_icon = ft.Icon(icon, size=120, tooltip=tooltip)
        else:
            feature_icon = ft.Icon(icon, size=80, tooltip=tooltip)
        feature_text = ft.Text(value=text, expand=True, weight=ft.FontWeight.W_500)

        if self.Page.width > 468:
            return Column([Container(feature_icon), Container(feature_text, alignment=ft.alignment.center_right)])
        else:
            return Column([Container(feature_icon), Container(feature_text, alignment=ft.alignment.center)])


class SearchPage(ft.Column):
    def __init__(self):
        super().__init__()

        self.search_field = TextField("Search...", False)
        self.search_icon = ft.IconButton(ft.icons.SEARCH_ROUNDED, expand=True)
        self.search_panel = Row([Container(self.search_field, expand=True),
                                 Container(self.search_icon, padding=ft.padding.only(left=-5, right=-5))])

        self.controls = [self.search_panel]


class UploadPage(ft.Column):
    def __init__(self):
        super().__init__()

        plus_icon = ft.Icon(ft.icons.ADD_ROUNDED, color="blue300")
        upload_field_text = ft.Text(value="Import", size=14, weight=ft.FontWeight.W_400)
        second_text = ft.Text(value="Videos, Audios, Images, Docs, etc.", weight=ft.FontWeight.W_100, size=11)
        upload_field = Container(Column([
            Row([plus_icon, upload_field_text], alignment=ft.MainAxisAlignment.CENTER),
            Row([second_text], alignment=ft.MainAxisAlignment.CENTER)
        ], alignment=ft.MainAxisAlignment.CENTER), border_radius=10, height=240, border=ft.border.all(2), expand=True,
            padding=ft.padding.only(left=50, right=50))

        private_check_box = ft.Checkbox(label="Private", label_position=ft.LabelPosition.RIGHT, height=50)

        self.submit_button = Button(text="Upload To Archive")
        self.submit_button.expand = True

        self.controls = [Row([upload_field], alignment=ft.MainAxisAlignment.CENTER),
                         Container(padding=10),
                         Row([private_check_box], alignment=ft.MainAxisAlignment.CENTER),
                         Container(padding=15),
                         Row([self.submit_button], alignment=ft.MainAxisAlignment.CENTER)]


def main(page: ft.Page):
    #Basic Settings
    page.title = "Archive"
    page.window.center()
    #Basic Settings

    nav_bar = Row(alignment=ft.MainAxisAlignment.END)
    pop_up_button = ft.PopupMenuButton()

    home_page = HomePage(page)
    search_page = SearchPage()
    upload_page = UploadPage()

    def resize_func(e):
        if page.width > 468:
            nav_bar.controls = [Container(Row([NavButton("Home", switch_to_home), NavButton("Search", switch_to_search),
                                               NavButton("Upload", switch_to_upload), NavButton("My Archives"),
                                               NavButton("About")]), padding=15)]
            home_page.features.content = Row(
                [home_page.upload_feature, home_page.secure_feature, home_page.download_feature],
                alignment=ft.MainAxisAlignment.SPACE_EVENLY)

            home_page.upload_feature.content.controls[0].content.size = 120
            home_page.upload_feature.content.controls[1].alignment = ft.alignment.center_right
            home_page.upload_feature.content.controls[1].content.size = 16
            home_page.download_feature.content.controls[0].content.size = 120
            home_page.download_feature.content.controls[1].alignment = ft.alignment.center_right
            home_page.download_feature.content.controls[1].content.size = 16
            home_page.secure_feature.content.controls[0].content.size = 120
            home_page.secure_feature.content.controls[1].alignment = ft.alignment.center_right
            home_page.secure_feature.content.controls[1].content.size = 16
            page.update()

        elif page.width < 468:
            pop_up_button.items = [
                pop_up_menu_item("Home", switch_to_home, ft.icons.HOME),
                pop_up_menu_item("Search", switch_to_search, ft.icons.SEARCH),
                pop_up_menu_item("Upload", switch_to_upload, ft.icons.UPLOAD),
                pop_up_menu_item("My Archives", icon=ft.icons.ARCHIVE),
                pop_up_menu_item(),
                pop_up_menu_item("About"),
                pop_up_menu_item("Help")
            ]
            nav_bar.controls = [pop_up_button]

            home_page.upload_feature.content.controls[0].content.size = 80
            home_page.upload_feature.content.controls[1].alignment = ft.alignment.center_right
            home_page.upload_feature.content.controls[1].content.size = 12
            home_page.download_feature.content.controls[0].content.size = 80
            home_page.download_feature.content.controls[1].alignment = ft.alignment.center_right
            home_page.download_feature.content.controls[1].content.size = 12
            home_page.secure_feature.content.controls[0].content.size = 80
            home_page.secure_feature.content.controls[1].alignment = ft.alignment.center_right
            home_page.secure_feature.content.controls[1].content.size = 12
            page.update()

    def switch_to_home(e):
        page_container.content = home_page
        page.update()

    def switch_to_search(e):
        page_container.content = search_page
        page.update()

    def switch_to_upload(e):
        page_container.content = upload_page
        page.update()

    def browse(e):
        page_column.auto_scroll = True
        page.update()
        time.sleep(1)
        page_column.auto_scroll = False
        page.update()

    def pop_up_menu_item(item=None, func=None, icon=None):
        stuff = ft.PopupMenuItem(text=item, on_click=func, icon=icon)
        return stuff

    if page.width > 700:
        nav_bar.controls = [Container(Row([NavButton("Home", switch_to_home), NavButton("Search", switch_to_search),
                                           NavButton("Upload", switch_to_upload), NavButton("My Archives"),
                                           NavButton("About")]), padding=15)]
        page.update()
    elif page.width < 700:
        pop_up_button.items = [
            pop_up_menu_item("Home", switch_to_home, ft.icons.HOME),
            pop_up_menu_item("Search", switch_to_search, ft.icons.SEARCH),
            pop_up_menu_item("Upload", switch_to_upload, ft.icons.UPLOAD),
            pop_up_menu_item("My Archives", icon=ft.icons.ARCHIVE),
            pop_up_menu_item(),
            pop_up_menu_item("About"),
            pop_up_menu_item("Help")
        ]
        nav_bar.controls = [pop_up_button]
        page.update()

    page_container = Container(padding=ft.padding.only(top=40, left=20, right=20), content=home_page, adaptive=True)
    page_column = Column([page_container], scroll=ft.ScrollMode.AUTO, adaptive=True, height=500, on_scroll_interval=0)

    if page.height < 650:
        page_column.height = 500
    elif page.height > 650:
        page_column.height = 600

    main_column = Column([nav_bar, page_column])
    background = Container(content=main_column, margin=-10)

    page.add(background)

    page.on_resized = resize_func
    home_page.browse_button.on_click = browse
    home_page.upload_button.on_click = switch_to_upload

    page.update()


ft.app(target=main)
